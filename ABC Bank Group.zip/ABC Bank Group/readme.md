## Banking Application
- As an user, I would like have create account facility
- As an user, I would like to deposit money to my account
- As an user. I would like to withdraw money from my account
- As an user I would like to check balance of my account
- As an user I would like to transfer money from my account to other account